# callofthehunt
Call of the Hunt bootstrap rework

Link: https://www.callofthehunt.com/
Mail: hello@callofthehunt.com
Author, development, business: https://www.facebook.com/vladimir.osipov.7
